export type size = 'sm' | 'lg';
