import { InputTemplateProps } from '../InputTemplate/types';

type RadioProps = Omit<InputTemplateProps, 'toggleSwitch'>;

export { RadioProps };
