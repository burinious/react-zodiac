import * as React from 'react';
import { ValidationItemProps } from './types';

declare const MDBValidationItem: React.FunctionComponent<ValidationItemProps>;

export default MDBValidationItem;
