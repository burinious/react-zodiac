interface PaginationLinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  ref?: React.Ref<HTMLAnchorElement>;
  tag?: React.ComponentProps<any>;
}

export { PaginationLinkProps };
