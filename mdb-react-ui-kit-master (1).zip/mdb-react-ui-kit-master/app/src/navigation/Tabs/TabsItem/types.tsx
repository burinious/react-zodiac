interface TabsItemProps extends React.LiHTMLAttributes<HTMLLIElement> {
  ref?: React.Ref<any>;
}

export { TabsItemProps };
