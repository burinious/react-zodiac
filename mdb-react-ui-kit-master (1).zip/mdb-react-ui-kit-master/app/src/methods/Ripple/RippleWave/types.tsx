import React from 'react';

type RippleWaveProps = {
  [rest: string]: any;
};

export { RippleWaveProps };
