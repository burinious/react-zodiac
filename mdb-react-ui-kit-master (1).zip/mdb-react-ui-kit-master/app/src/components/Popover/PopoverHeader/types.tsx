interface PopoverHeaderProps extends React.AllHTMLAttributes<HTMLHeadElement> {
  tag?: React.ComponentProps<any>;
}

export { PopoverHeaderProps };
