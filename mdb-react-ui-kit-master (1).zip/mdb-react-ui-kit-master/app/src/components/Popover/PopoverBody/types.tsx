import { BaseComponent } from '../../../types/baseComponent';

interface PopoverBodyProps extends BaseComponent {
  tag?: React.ComponentProps<any>;
}

export { PopoverBodyProps };
