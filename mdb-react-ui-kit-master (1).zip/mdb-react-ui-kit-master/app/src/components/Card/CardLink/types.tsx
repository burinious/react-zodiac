type CardLinkProps = React.AnchorHTMLAttributes<HTMLAnchorElement>;

export { CardLinkProps };
