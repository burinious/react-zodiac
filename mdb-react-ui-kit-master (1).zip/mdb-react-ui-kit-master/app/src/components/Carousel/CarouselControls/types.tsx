type CarouselControlsProps = {
  move: (direction: 'prev' | 'next') => void;
};

export { CarouselControlsProps };
