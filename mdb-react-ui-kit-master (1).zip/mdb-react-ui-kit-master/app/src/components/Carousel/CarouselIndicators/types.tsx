type CarouselIndicatorsProps = {
  imagesCount: number;
  to: (id: number) => void;
};

export { CarouselIndicatorsProps };
