type TableBodyProps = React.HTMLAttributes<HTMLElement>;

export { TableBodyProps };
