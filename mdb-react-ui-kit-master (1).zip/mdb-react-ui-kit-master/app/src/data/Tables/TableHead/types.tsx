interface TableHeadProps extends React.HTMLAttributes<HTMLElement> {
  dark?: boolean;
  light?: boolean;
}

export { TableHeadProps };
